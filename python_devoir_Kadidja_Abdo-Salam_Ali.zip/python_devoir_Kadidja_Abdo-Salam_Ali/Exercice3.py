
import string

def nettoyer_chaine(chaine):
    # Enlever les espaces et la ponctuation, et convertir en minuscules
    chaine = chaine.lower()
    return ''.join(char for char in chaine if char in string.ascii_lowercase or char.isdigit())

def est_palindrome(chaine):
    # Nettoyer la chaîne
    chaine_nettoyee = nettoyer_chaine(chaine)
    # Vérifier si la chaîne nettoyée est égale à sa version inversée
    return chaine_nettoyee == chaine_nettoyee[::-1]

# Tester avec différents exemples
mots = ["radar", "Kadidja", "1221", "A man, a plan, a canal, Panama", "12321", "12345"]

for mot in mots:
    if est_palindrome(mot):
        print(f"'{mot}' est un palindrome.")
    else:
        print(f"'{mot}' n'est pas un palindrome.")  