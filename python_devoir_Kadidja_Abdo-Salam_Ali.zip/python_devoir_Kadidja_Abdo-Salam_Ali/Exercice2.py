def calculate_bmi(poids,taille):
    poids=float(input("Entrer votre poids:")) #on demande a l'utilisateur son poids en kilogramme
    taille=float(input("Entrer votre taille:")) #on demande a l'utilisateur sa taille en metre
    poidslivre=poids*2.20462 # pour convertir poids de kilograme en livres
    print("le poids en livre est:",poidslivre)
    taillepouces=taille*39.3701 # pour convertir taille de metre en pouces
    print("le taille en pouces est:",taillepouces)
    taillecarre=taille*taille
    print(taillecarre)
    icm=(poids/taillecarre)

    if icm<18.5:
        print("insuffissance ponderal")
    elif icm>=18.5 and icm<=24.9:
        print("poids normale")
    elif icm>=25 and icm<=29.9:
        print("Surpoids")
    elif icm>=30:
        print("obesite")
    else:
        print("None")       
      
     
    return icm

total=calculate_bmi(60.0,1.79)
print("le valeur d'ICM est:",total)