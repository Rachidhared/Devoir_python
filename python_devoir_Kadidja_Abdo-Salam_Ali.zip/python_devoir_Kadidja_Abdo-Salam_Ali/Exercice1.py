
def plateau(n, m):
    # Créer une matrice n x m remplie d'étoiles
    matrice = [['*' for _ in range(m)] for _ in range(n)]
    return matrice


def afficher_plateau(matrice):
    for ligne in matrice:
        print(' '.join(ligne))

# Définir la taille de la matrice
n = int(input("Enter number of rows"))  # nombre de lignes
m = int(input("Enter number of columns")) # nombre de colonnes

# Créer et afficher le plateau d'étoiles
matrice = plateau(n, m)
afficher_plateau(matrice)
   

      